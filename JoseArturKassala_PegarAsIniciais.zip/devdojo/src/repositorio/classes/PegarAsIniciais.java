package repositorio.classes;

public class PegarAsIniciais {
    private String letra, iniciais="";
    //private char[] caracter = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    public PegarAsIniciais(String args){
        this.letra=args;
    }

    public String getIniciais(){

        try {
            if(this.letra.substring(0,0)!="") {
                this.iniciais+=this.letra.charAt(0);
                for (int i = 0; i < this.letra.length(); i++) {

                    if (this.letra.charAt(i) == ' ') {
                        this.iniciais += letra.charAt(i + 1);
                    }

                }
            }
            return this.iniciais;
        }catch (StringIndexOutOfBoundsException e){
            return "Nenhum caracter encontrado";
        }

    }



}
