package repositorio.teste;

import repositorio.classes.PegarAsIniciais;

public class SudomakeTeste {
    public static void main(String[] args) {
        PegarAsIniciais pegarAsIniciais = new PegarAsIniciais("Jose Artur Kassala");
        System.out.println(pegarAsIniciais.getIniciais());
    }
}
